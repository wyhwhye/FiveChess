import java.io.IOException;

public class FiveChess {
    public static void main(String[] args) throws IOException {
        FiveChessFrame f = new FiveChessFrame();
    }
}
